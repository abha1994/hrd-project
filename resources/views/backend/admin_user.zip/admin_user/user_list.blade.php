@extends('layouts.master')
@section('container')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Officer Management</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Officer Management</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <div class="container-fluid border-top bg-white card-footer text-muted text-left" id="app">        
        <div class="pull-right" style="float: right;">
        @can('user-create')
            <a class="btn btn-success" href="{{ URL('user/create ') }}"><i class="nav-icon fas fa-plus"></i> Officer</a>
            @endcan

        </div>
        <br />
        <br />
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <br />
            <table class="table table-bordered">
                
                <thead>
                <tr>
				  <th id="sort">S. No.</th>
                  <th>Officer Name</th>
                  <th>Designation</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
                    
               @foreach ($data as $key => $user)
				  <tr>
				  <td> {{ $loop->iteration }} </td>
                  <td><?php echo $user->name;?></td>
                  <td><?php echo $user->designation;?></td>
                  <td>  @if(!empty($user->getRoleNames()))
        @foreach($user->getRoleNames() as $v)
           <label class="badge badge-success">{{ $v }}</label>
        @endforeach
      @endif
				    
				  </td>
                  <td>
				    

           <a href="{{url('changeStatus/'.$user->id)}}">
              <?php if($user->status==1){echo '<div class ="text-success text-toggle-color"><i class="fa fa-toggle-on fa-2x" aria-hidden="true"></i></div>';}else{echo '<div class="text-secondary"><i class="fa fa-toggle-off fa-2x" aria-hidden="true"></i></div>';}?>
              </a>

				  </td>
          <td style="width: 217px;">
            <form action="{{ route('user.destroy',$user->id) }}" method="POST">
				      <a class="btn btn-info" href="{{ url('user/'.$user->id) }}" style="color: white">Show</a>
              @can('user-edit')
              <a class="btn btn-primary" href="{{ url('user/'.$user->id.'/edit') }}">Edit</a>
             @endcan
                    @csrf
                    @method('DELETE')
                   @can('user-delete')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
                    @endcan
                   
                </form>
				     
				  </td>
				  </tr>
				@endforeach
            </table>
             
        </div> 
    </div>
     <script src="{{ asset('js/app.js') }}"></script> 
@endsection
