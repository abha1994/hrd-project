@extends('layouts.master')
@section('container')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"> Details of Officer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Details of Officer</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <div class="container-fluid" id="app">        
        <div class="container-fluid border-top bg-white card-footer text-muted text-left " id="app">        
    		<div class="col-md-8 center">
    			<div class="card card-primary card-outline">
        			<div class="card-body">      
       				 <br />           
       				 <div class="table-responsive">
           				<table class="table">
           					<tr> 
           						<td>Officer Name : </td><td>{{$data->name}}</td>
           					</tr>
           					<tr> 
           						<td>Designation : </td><td>{{$data->designation}}</td>
           					</tr>
           					<tr> 
           						<td>Mobile Numer : </td><td>{{$data->mobile_no}}</td>
           					</tr>
           					<tr> 
           						<td>Joining Date : </td><td>{{$data->joining_date}}</td>
           					</tr>
           					<tr> 
           						<td>Transfer Date : </td><td>{{$data->transfer_date}}</td>
           					</tr>
           					<tr> 
           						<td>Date of Birth : </td><td>{{$data->dob}}</td>
           					</tr>

           					<tr><td></td><td style="float:right"><a href="{{url('user')}}" class="btn btn-secondary">Back</a></td></tr>
           				</table>
           			</div>
           			</div>
           		</div>
           	</div>
           </div>
        </div> 
    </div>
    <script src="{{ asset('js/app.js') }}"></script> 
@endsection
