@extends('layouts.master')
@section('container')
 	<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs--><br>
      <ol class="breadcrumb" >
        <li class="breadcrumb-item">
          <a href="{{url('home')}}">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">National Renewable Energy Fellowships</li>
      </ol>
    </div> 
	</div>
@endsection
